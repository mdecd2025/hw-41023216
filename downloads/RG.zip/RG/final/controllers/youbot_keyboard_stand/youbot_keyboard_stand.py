from controller import Robot, Keyboard

# Constants
TIME_STEP = 32  # Simulation time step in milliseconds
WHEEL_RADIUS = 0.1  # Radius of the wheels in meters (10cm)
L = 0.471  # Half of the robot's length in meters
W = 0.376  # Half of the robot's width in meters
MAX_VELOCITY = 10.0  # Maximum velocity allowed for the wheels

# Initialize the robot
robot = Robot()

# Initialize the keyboard
keyboard = Keyboard()
keyboard.enable(TIME_STEP)

# Get motor devices
wheel5 = robot.getDevice("wheel5")  # Front-right wheel
wheel6 = robot.getDevice("wheel6")  # Front-left wheel
wheel7 = robot.getDevice("wheel7")  # Rear-right wheel
wheel8 = robot.getDevice("wheel8")  # Rear-left wheel

# Set motors to velocity control mode
for wheel in [wheel5, wheel6, wheel7, wheel8]:
    wheel.setPosition(float('inf'))  # Enable velocity control
    wheel.setVelocity(0)  # Set initial velocity to 0

def set_wheel_velocity(v1, v2, v3, v4):
    """Set the velocity of all wheels."""
    wheel5.setVelocity(v1)
    wheel6.setVelocity(v2)
    wheel7.setVelocity(v3)
    wheel8.setVelocity(v4)

# Main loop
print("Use 'E', 'X', 'S', 'D' keys to control the robot.")
print("E: Move forward, X: Move backward, S: Turn left, D: Turn right.")
print("Press 'Q' to quit.")

while robot.step(TIME_STEP) != -1:
    key = keyboard.getKey()  # Read the key pressed

    if key == ord('E') or key == ord('e'):
        # Move forward
        velocity = MAX_VELOCITY
        set_wheel_velocity(velocity, velocity, velocity, velocity)
    elif key == ord('X') or key == ord('x'):
        # Move backward
        velocity = -MAX_VELOCITY
        set_wheel_velocity(velocity, velocity, velocity, velocity)
    elif key == ord('D') or key == ord('d'):
        # Turn right
        velocity = MAX_VELOCITY
        set_wheel_velocity(-velocity, velocity, -velocity, velocity)
    elif key == ord('S') or key == ord('s'):
        # Turn left
        velocity = MAX_VELOCITY
        set_wheel_velocity(velocity, -velocity, velocity, -velocity)
    elif key == ord('Q') or key == ord('q'):
        # Quit the program
        print("Exiting...")
        break
    else:
        # Stop the wheels when no key is pressed
        set_wheel_velocity(0, 0, 0, 0)